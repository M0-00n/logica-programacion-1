package diccionarioEspIng;

import java.util.*;

public class DiccionarioEspIng {
    public static void main(String[] args) {
        //HashMap para el diccionario
        Map<String,String> diccionario = crearDiccionario();
        // 2. Seleccionar 5 palabras al azar
        List<String> palabrasSeleccionadas = palabrarsAlAzar(diccionario);

        // 3. Realizar el cuestionario
        int[] resultados = cuestionario(palabrasSeleccionadas, diccionario);

        // 4. Mostrar resultados
        mostrarResultados(resultados);
    }

    // Metodo para crear diccionario
    private static Map<String,String> crearDiccionario(){
        Map<String,String> diccionario = new HashMap<>(); //Nueva instancia del HashMap

        diccionario.put("perro", "dog");
        diccionario.put("aberración", "aberration");
        diccionario.put("botella", "bottle");
        diccionario.put("burocracia", "bureaucracy");
        diccionario.put("libertad", "freedom");
        diccionario.put("travieso", "mischievous");
        diccionario.put("pájaro", "bird");
        diccionario.put("molesto", "bothersome");
        diccionario.put("ventana", "window");
        diccionario.put("agotador", "grueling");
        diccionario.put("gato", "cat");
        diccionario.put("apostar", "gambling");
        diccionario.put("tosco", "rough");
        diccionario.put("mayúsculo", "egregious");
        diccionario.put("bruto", "gross");
        diccionario.put("descarado", "blatant");
        diccionario.put("dedos", "fingers");
        diccionario.put("indiferencia", "disregard");
        diccionario.put("encantador", "lovely");
        diccionario.put("admiración", "respect");


        return diccionario;
    }

    // Metodo mezclar palabras
    private static List<String> palabrarsAlAzar(Map<String,String> diccionario) {
        List<String> palabras =new ArrayList<>(diccionario.keySet());
        Collections.shuffle(palabras);
        return palabras.subList(0,5);
    }

    //Cuestionario
    private static int[] cuestionario (List<String> palabras, Map<String,String> diccionario){
        Scanner scanner =new Scanner(System.in);
        int correctas=0;
        int incorrectas=0;

        System.out.println("Traduce las siguientes 5 palabras al inglés:");

        for (String palabraEsp : palabras){
            System.out.printf(palabraEsp + ": ");
            String respIngles = scanner.nextLine().toLowerCase().trim();
            String traduccion = diccionario.get(palabraEsp);

            if (respIngles.equals(traduccion)){
                System.out.println("Correcto. " );
                correctas++;
            } else {
                System.out.println("Incorrecto. " + traduccion);
                incorrectas++;
            }
        }
        scanner.close();
        return new int[] {correctas,incorrectas};
    }

    // Resultados
    private static void mostrarResultados(int[] resultados) {
        System.out.println("Resultados");
        System.out.println("Respuestas correctas: "+ resultados[0]);
        System.out.println("Respuestas incorrectas: "+ resultados[1]);
    }


}
